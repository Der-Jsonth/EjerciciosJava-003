package com.example.hotel;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.text.NumberFormat;
import java.util.Locale;

public class RegistroController {
    @FXML private TextField txtNombre;
    @FXML private ComboBox<String> cmbPlaneta;
    @FXML private ComboBox<String> cmbHabitacion;
    @FXML private TextField txtNoches;
    @FXML private CheckBox chkDesayuno;
    @FXML private CheckBox chkSpeeder;
    @FXML private Label lblResultado;

    @FXML
    private void initialize() {
        cmbPlaneta.getItems().addAll(
                "Tatooine", "Naboo", "Coruscant", "Hoth"
        );
        cmbHabitacion.getItems().addAll(
                "Habitación estándar rebelde",
                "Suite Jedi", "Suite Imperial"
        );
    }

    @FXML
    private void calcularReserva() {
        String nombre = txtNombre.getText().trim();
        String planeta = cmbPlaneta.getValue();
        String habitacion = cmbHabitacion.getValue();
        String nochesTexto = txtNoches.getText().trim();
        boolean desayuno = chkDesayuno.isSelected();
        boolean speeder = chkSpeeder.isSelected();

        if (nombre.isEmpty() || planeta == null ||
                habitacion == null || nochesTexto.isEmpty()) {
            lblResultado.setText(
                    "Complete el nombre, planeta, habitación y noches."
            );
            return;
        }

        int noches;
        try {
            noches = Integer.parseInt(nochesTexto);
        } catch (NumberFormatException e) {
            lblResultado.setText(
                    "Las noches deben ser un número entero."
            );
            return;
        }

        if (noches <= 0) {
            lblResultado.setText(
                    "La cantidad de noches debe ser mayor que cero."
            );
            return;
        }


        // montos

        int precioPorNoche;
        if (habitacion.equals("Habitación estándar rebelde")) {
            precioPorNoche = 45000;
        } else if (habitacion.equals("Suite Jedi")) {
            precioPorNoche = 70000;
        } else if (habitacion.equals("Suite Imperial")) {
            precioPorNoche = 95000;
        } else {
            lblResultado.setText("Habitación no válida.");
            return;
        }

        int costoHabitacion = precioPorNoche * noches;
        int costoDesayuno = desayuno ? 8000 * noches : 0;
        int costoSpeeder = speeder ? 15000 : 0;
        int total = costoHabitacion + costoDesayuno + costoSpeeder;

        String totalFormateado = NumberFormat
                .getIntegerInstance(Locale.forLanguageTag("es-CL"))
                .format(total);

        lblResultado.setText(
                "Reserva simulada para " + nombre + " en " + planeta + ".\n" +
                        "Total a pagar: $" + totalFormateado
        );
    }

    @FXML
    private void limpiarFormulario() {
        txtNombre.clear();
        cmbPlaneta.getSelectionModel().clearSelection();
        cmbHabitacion.getSelectionModel().clearSelection();
        txtNoches.clear();
        chkDesayuno.setSelected(false);
        chkSpeeder.setSelected(false);
        lblResultado.setText("Aquí aparecerá el total de la reserva");
        txtNombre.requestFocus();
    }



}